drop sequence REPLY2_IDX_REPLY;
drop table REPLY2;
drop sequence JSP_BOARD2_IDX;
drop table JSP_BOARD2;

drop sequence REPLY1_IDX_REPLY;
drop table REPLY1;
drop sequence JSP_BOARD1_IDX;
drop table JSP_BOARD1;

drop sequence REPLY_IDX_REPLY;
drop table REPLY;
drop sequence JSP_BOARD_IDX;
drop table JSP_BOARD;

drop sequence JSP_MEMBER_NO;
drop table JSP_MEMBER;
