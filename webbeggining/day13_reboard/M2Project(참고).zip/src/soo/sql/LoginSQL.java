package soo.sql;

public class LoginSQL {
    public static final String LOGIN_SELECT_ID 
	= "SELECT * FROM jsp_member WHERE id=?";
}
