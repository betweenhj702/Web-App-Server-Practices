package soo.path;

public class M2ProjectPath {
	public static String RB_UPLOAD_DIR = "";
}
/*
 * 
public final static String RB_UPLOAD_DIR
	   = "C:/M2Pj/eclipse/workspace/.metadata/.plugins/org.eclipse.wst.server.core/tmp0/wtpwebapps/M2P/reboard/store";
	   

 * */
